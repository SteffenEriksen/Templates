﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using $safeprojectname$.Entities.Models;

namespace $safeprojectname$.Services.Interface
{
    public interface IService
    {
        ExampleModel Get();
        IEnumerable<ExampleModel> GetAll();
        ExampleModel Do();
    }
}
