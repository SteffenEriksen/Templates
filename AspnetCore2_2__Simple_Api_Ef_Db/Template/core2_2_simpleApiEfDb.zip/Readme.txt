﻿

##### Run in powershell / Package Manager Console


## To add migrations and to sync database structure in project to database 

$ Add-Migration Init
$ Update-Database



## To generate SQL Scripts based on migrations

$ Script-Migration
